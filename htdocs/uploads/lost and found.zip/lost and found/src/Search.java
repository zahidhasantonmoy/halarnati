import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Search extends JFrame implements ActionListener {

    JTextField searchField = new JTextField();
    String[] item_list = {"Phone", "Vehicle", "ID Card", "Wallet", "Keys", "Jewelry", "Electronics", "Clothing", "Accessories", "Books", "Documents", "Others"};
    JComboBox itemcatagory = new JComboBox(item_list);
    JComboBox<String> colorField;
    JCheckBox lostTableCheckbox, foundTableCheckbox;
    JButton searchButton = new JButton("Search");
    JButton backButton = new JButton("Back to Homepage");

    public Search() {
        setTitle("Search Lost and Found Items");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1080, 720);
        setLayout(new BorderLayout());

        JPanel containerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Load the background image
                ImageIcon backgroundImage = new ImageIcon("bgg.jpg");
                // Draw the background image
                g.drawImage(backgroundImage.getImage(), 0, 0, getWidth(), getHeight(), this);
            }
        };

        containerPanel.setLayout(new BorderLayout());
        containerPanel.setBorder(BorderFactory.createEmptyBorder(50, 200, 50, 200));

        JLabel titleLabel = new JLabel("Search Lost and Found Items");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 36));
        titleLabel.setForeground(Color.decode("#4CAF50"));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        containerPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel();
        formPanel.setBackground(Color.white);
        formPanel.setLayout(new GridLayout(5, 2, 0, 15));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        searchField.setPreferredSize(new Dimension(400, 40));
        searchField.setBorder(BorderFactory.createTitledBorder("Search Keywords"));
        formPanel.add(searchField);

        itemcatagory.setPreferredSize(new Dimension(400, 40));
        itemcatagory.setBorder(BorderFactory.createTitledBorder(" Item Category"));
        formPanel.add(itemcatagory);

        String[] colorOptions = {"Red", "Green", "Blue", "Yellow", "Black", "White", "Other"};
        colorField = new JComboBox<>(colorOptions);
        colorField.setPreferredSize(new Dimension(400, 40));
        colorField.setBorder(BorderFactory.createTitledBorder("Item Color"));
        formPanel.add(colorField);

        lostTableCheckbox = new JCheckBox("Search in Lost Items Table");
        formPanel.add(lostTableCheckbox);

        foundTableCheckbox = new JCheckBox("Search in Found Items Table");
        formPanel.add(foundTableCheckbox);

        searchButton.setBackground(Color.decode("#4CAF50"));
        searchButton.setForeground(Color.white);
        searchButton.setPreferredSize(new Dimension(400, 40));
        formPanel.add(searchButton);

        containerPanel.add(formPanel, BorderLayout.CENTER);
        add(containerPanel, BorderLayout.CENTER);

        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(Color.decode("#f4f4f4"));

        backButton.setBackground(Color.decode("#f44336"));
        backButton.setForeground(Color.white);
        backButton.setPreferredSize(new Dimension(200, 40));
        footerPanel.add(backButton);
        containerPanel.add(footerPanel, BorderLayout.SOUTH);

        backButton.addActionListener(this);
        searchButton.addActionListener(this);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Search::new);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == backButton) {
            dispose();
            new Homepage();
        }
        if (e.getSource() == searchButton) {

            String url = "jdbc:mysql://localhost:3306/lostandfound";
            String UserName = "root";
            String Password = "";

            try {
                // 1. Load the database driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // 2. Establish a connection
                Connection connection = DriverManager.getConnection(url, UserName, Password);

                String productName = searchField.getText();
                int category = itemcatagory.getSelectedIndex();
                String color = colorField.getSelectedItem().toString(); // Get the selected color
                boolean searchLostTable = lostTableCheckbox.isSelected();
                boolean searchFoundTable = foundTableCheckbox.isSelected();

                StringBuilder queryBuilder = new StringBuilder("SELECT * FROM ");
                if (searchLostTable && searchFoundTable) {
                    queryBuilder.append("(lost_item UNION ALL found_item)");
                } else if (searchLostTable) {
                    queryBuilder.append("lost_item");
                } else if (searchFoundTable) {
                    queryBuilder.append("found_item");
                } else {
                    JOptionPane.showMessageDialog(null, "Please select at least one table to search.");
                    return;
                }

                queryBuilder.append(" WHERE item1 = ? AND itemcolor5 = ? AND itemcatagory = ?");

                PreparedStatement preparedStatement = connection.prepareStatement(queryBuilder.toString());
                preparedStatement.setString(1, productName);
                preparedStatement.setString(2, color);
                preparedStatement.setInt(3, category);

                // Execute the query
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    dispose();
                    System.out.println("Item found");
                    ItemDetails D = new ItemDetails();

                    String itemname = resultSet.getString("item1");
                    String NaMe = resultSet.getString("foundername2");
                    String founderphone = resultSet.getString("founderphone3");
                    String email = resultSet.getString("email4");
                    String location6 = resultSet.getString("location6");
                    String founderid7 = resultSet.getString("founderid7");
                    String description8 = resultSet.getString("description8");
                    String founddate9 = resultSet.getString("founddate9");

                    D.productFounder.setText("Founder:  " + NaMe);
                    D.productName.setText("Your item: " + itemname);
                    D.Address.setText("ADDRESS: " + location6);
                    D.FounderPhone.setText("Contact: " + founderphone);
                    D.email.setText("Email:  " + email);
                    D.itemcolor.setText("Item color: " + color);
                    D.founderid.setText("STUDENT ID: " + founderid7);
                    D.description.setText("Description : " + description8);
                    D.date.setText("Found date : " + founddate9);

                    JOptionPane.showMessageDialog(null, "Item Found!", "Done", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Item not found.", "Failed", JOptionPane.ERROR_MESSAGE);
                    System.out.println("Item not found: " + productName + "::" + category);
                }

                // Close resources
                resultSet.close();
                preparedStatement.close();
                connection.close();

            } catch (SQLException | ClassNotFoundException ex) {
                ex.printStackTrace();
                System.out.println("Database connection or query execution error.");
            }
        }
    }
}
