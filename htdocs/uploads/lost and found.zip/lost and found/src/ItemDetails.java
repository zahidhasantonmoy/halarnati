import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ItemDetails extends JFrame implements ActionListener {
     JFrame FRAME = new JFrame();
    JLabel TITLE= new JLabel();
     JLabel productFounder= new JLabel();
    JLabel productName= new JLabel();
    JLabel FounderPhone= new JLabel();
    JLabel Address= new JLabel();
    JLabel email= new JLabel();
    JLabel founderid= new JLabel();
    JLabel itemcolor= new JLabel();
    JLabel date= new JLabel();
    JLabel description = new JLabel();
    JButton homepage = new JButton();
    ImageIcon contact = new ImageIcon("phone-call.png");
    ImageIcon addressimage = new ImageIcon("home-address.png");
    ImageIcon founderimage = new ImageIcon("face-scan.png");
    ImageIcon calendar = new ImageIcon("calendar.png");
    ImageIcon email_image = new ImageIcon("gmail.png");
    ImageIcon ur_item = new ImageIcon("mobile-phone .png");
    ImageIcon description_image = new ImageIcon("description.png");
    ImageIcon homepage_image = new ImageIcon("homepage.png");
    JLabel contact_image= new JLabel();
    JLabel address= new JLabel();
    JLabel founder= new JLabel();
    JLabel found_date= new JLabel();
    JLabel your_item= new JLabel();
    JLabel founder_email= new JLabel();
    JLabel founder_id= new JLabel();
    JLabel item_description= new JLabel();

    ItemDetails(){

        FRAME.setBounds(0,0,1080,720);

        FRAME.getContentPane().setBackground(new Color(0xF8CB97));
        homepage.setBackground(new Color(0xC7C574));



        FRAME.setDefaultCloseOperation(FRAME.EXIT_ON_CLOSE);
        FRAME.setVisible(true);
        FRAME.setLayout(null);

        FRAME.add(productFounder);
        FRAME.add(TITLE);
        FRAME.add(productName);
        FRAME.add(FounderPhone);
        FRAME.add(Address);
        FRAME.add(homepage);
        FRAME.add(founderid);
        FRAME.add(date);
        FRAME.add(email);
        FRAME.add(description);
        FRAME.add(contact_image);

        FRAME.add(founder_email);
        FRAME.add(founder_id);
        FRAME.add(founder_email);
        FRAME.add(found_date);
        FRAME.add(your_item);
        FRAME.add(item_description);
        FRAME.add(founder);
        FRAME.add(address);

        TITLE.setBounds(200,10,400,40);
        founder_id.setBounds(120,50,32,32);
        founderid.setBounds(150,50,400,40);

        founder.setBounds(110,105,32,32);
        productFounder.setBounds(150,100,400,50);

        your_item.setBounds(110,165,32,32);
        productName.setBounds(150,160,400,50);

        address.setBounds(110,225,32,32);
        Address.setBounds(150,220,400,50);

        contact_image.setBounds(110,285,32,32);
        FounderPhone.setBounds(150,280,400,50);

        founder_email.setBounds(110,345,32,32);
        email.setBounds(150,340,400,40);

        found_date.setBounds(110,385,32,32);
        date.setBounds(150,380,400,50);

        itemcolor.setBounds(150,440,400,50);

        item_description.setBounds(110,480,32,32);
        description.setBounds(150,480,400,50);


        homepage.setBounds(400,450,64,64);
        homepage.setFocusable(false);
        homepage.setIcon(homepage_image);

        contact_image.setIcon(contact);
        founder.setIcon(founderimage);
        found_date.setIcon(calendar);
        address.setIcon(addressimage);
        founder_email.setIcon(email_image);
        your_item.setIcon(ur_item);
        item_description.setIcon(description_image);



       // homepage.setText("GO HOME");
        TITLE.setText("LOST & FOUND");
        TITLE.setFont(new Font("OCR A Extended",Font.BOLD,30));
       productFounder.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        productName.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        Address.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        FounderPhone.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        homepage.setFont(new Font("OCR A Extended",Font.BOLD,10));

        email.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        itemcolor.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        date.setFont(new Font("OCR A Extended",Font.PLAIN,20));
        description.setFont(new Font("OCR A Extended",Font.BOLD,10));

        productFounder.setText("Founder:  ");
        productName.setText("Your item: ");
        Address.setText("Address: ");
        date.setText("Found date:  ");
        email.setText("Email: ");
        itemcolor.setText("Item color: ");

        homepage.addActionListener(this);


    }





    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==homepage){
            FRAME.dispose();
            Homepage homepage2= new Homepage();
        }

    }
}
